<?php
session_start();
date_default_timezone_set("Asia/Dubai");
$con = mysqli_connect("localhost","root","") or die("Unable to Connect");
mysqli_select_db($con,'hms');
$rndno=rand(100000, 999999);//OTP generate
$date = date('Y-m-d H:i:s');
$query="insert into otp values('', '$rndno', '$date')";
$query_run = mysqli_query($con,$query);// to actually connect and insert
if(!$query_run)// if insertion unsuccessful
{
	echo '<script> alert("Server Error... Please try again Later")</script>';
}
$message = urlencode("otp number.".$rndno);
$to=$_POST['email'];
$subject = "OTP";
$txt = "OTP: ".$rndno."";
$headers = "From: random_mail@gmail.com";
mail($to,$subject,$txt,$headers);
if(isset($_POST['submit_btn']))
{
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];
if($password==$cpassword)// to validate
{	
$_SESSION['fullname']=$_POST['fullname'];
$_SESSION['email']=$_POST['email'];
$_SESSION['gender']=$_POST['gender'];
$_SESSION['blood']=$_POST['blood'];
$_SESSION['date']=$_POST['date'];
$_SESSION['password']=$_POST['password'];
$_SESSION['otp']=$rndno;
 header( 'location:otp.php' );
} 
else
{
	header( 'location:room.php' );
	echo '<script> alert("Passwords dont Match... Please Re-enter Password")</script>';
}
}
?>