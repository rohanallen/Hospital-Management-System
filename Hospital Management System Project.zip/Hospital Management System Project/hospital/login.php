<?php
//login.php
session_start();
$con = mysqli_connect("localhost","root","") or die("Unable to Connect");
// name of database
mysqli_select_db($con,'hms');
if(isset($_POST["username"]) && isset($_POST["password"]))
{
    $username = $_POST['username'];
	$password = $_POST['password'];
	$encrypted_password = md5($password);
    $query="select * from corona WHERE email='$username' AND password='$encrypted_password'";
	$query_run = mysqli_query($con,$query);// // to actually connect and stores all info(row) regarding that username and password combination
	
	if(mysqli_num_rows($query_run)>0)
	{
		$data = mysqli_fetch_array($query_run);
		$_SESSION["username"] = $data["email"];
		echo $data["email"];
  
 }
}
?>