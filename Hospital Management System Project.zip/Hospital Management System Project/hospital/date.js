function setCheckIn()
{// to reset min check in date to current date
	var today = new Date();// to get current date
	var dd = today.getDate();// to get day
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();
	if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 

	today = yyyy+'-'+mm+'-'+dd;// to get current date into year month day format
	document.getElementById("checkin").setAttribute("min", today);// to reset min date
}