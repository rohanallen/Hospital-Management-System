
<!DOCTYPE HTML>
<html>
<head>
<title>COVID-19</title>
<!-- goes to the Login_Page_css folder and then gets the Login_Page.css file from that folder-->
<link rel="stylesheet" href="Login_Page.css">
<script type="text/javascript" src="date.js"></script>
</head>
<style>
#signup_btn{
background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  display: block;
  margin-left: auto;
  margin-right: auto;
}
</style>
<body style="background-color:#182C61;">
<div id="main-wrapper" style="background-color:#e74c3c;">
<center> 
<h2> Registration Form</h2> 
<!-- goes to the Login_Page_img folder and then gets the manu.png pic from that folder-->
</center>
<form class="myform" method="post" action="process.php">
<br>
<label> <b>Full Name:</label>
<br>
<br>
<input name ="fullname" type="text" class="inputvalues" placeholder="Enter Full Name" required/>
<br>
<br>
<label> <b>Email:</label>
<br>
<br>
<input name ="email" type="text" class="inputvalues" placeholder="Enter Email" required/>
<br>
<br>
<label> <b>Gender:</label>
<br>
<input type="radio" class="radiobtns" name="gender" value="male" checked required>Male
<input type="radio" class="radiobtns" name="gender" value="female" required>Female
<br>
<br>
<label> <b>Blood Type:</label>
<br>
<input type="radio" class="radiobtns" name="blood" value="A+" checked required>A+
<input type="radio" class="radiobtns" name="blood" value="A-" required>A-
<input type="radio" class="radiobtns" name="blood" value="B+" required>B+
<input type="radio" class="radiobtns" name="blood" value="B-" required>B-
<input type="radio" class="radiobtns" name="blood" value="O+"  required>0+
<input type="radio" class="radiobtns" name="blood" value="0-" required>0-
<input type="radio" class="radiobtns" name="blood" value="AB+" required>AB+
<input type="radio" class="radiobtns" name="blood" value="AB-" required>AB-
<br>
<br>
<label> <b>Booking Date:</label>
<br>
<input name ="date" type="date" id="checkin" class="inputvalues" placeholder="Enter Date" onclick="setCheckIn();" required/>
<br>
<br>
<label> <b> Password:</label>
<br>
<input name ="password" type="password" class="inputvalues" placeholder="Enter Password" required/>
<br><br>
<label> <b> Confirm Password:</label>
<br>
<input name ="cpassword" type="password" class="inputvalues" placeholder="Re-enter Password" required/>
<br><br>

<!-- type submit so that data is submitted to server on clicking button, method is post instead of get so that the user data is not shown in url space-->
<input name ="submit_btn" type="submit" id="signup_btn" value="Register"/>

<br>
</form>
</div>
</body>
</html>