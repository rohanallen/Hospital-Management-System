<?php
session_start();
date_default_timezone_set("Asia/Dubai");
$con = mysqli_connect("localhost","root","") or die("Unable to Connect");
mysqli_select_db($con,'hms');
if(isset($_POST['save']))
{
$rno=$_SESSION['otp'];
$urno=$_POST['otpvalue'];
//if(!strcmp($rno,$urno))
$query="select * from otp WHERE otp='$urno' AND NOW() <= DATE_ADD(createTime, INTERVAL 1 MINUTE)";
$query_run = mysqli_query($con,$query);// // to actually connect and stores all info(rows) regarding that username
if(mysqli_num_rows($query_run)>0)// if username exists already in DB
{
$fullname=$_SESSION['fullname'];
$email=$_SESSION['email'];
$gender=$_SESSION['gender'];
$blood=$_SESSION['blood'];
$date=$_SESSION['date'];
$password=$_SESSION['password'];
$encrypted_password = md5($password);
//For admin if he want to know who is register
$to="random_mail@gmail.com";
$subject = "Thank you!";
$txt = "Some one show your demo Email id: ".$email;
$headers = "From: random_mail@gmail.com";
mail($to,$subject,$txt,$headers);
$query="insert into corona values('','$fullname','$email','$gender','$blood','$date','$encrypted_password')";
$query_run = mysqli_query($con,$query);// to actually connect and insert
if($query_run)// if insertion successful
{
echo '<script> alert("Room Registration Succesfull")</script>';
header( 'location:index.php' );
}
else
{
	echo '<script> alert("Server Error... Please try again Later")</script>';
}

}
else{
echo '<script> alert("OTP Expired... Please Login Again")</script>';
header( 'location:room.php' );
}
}
//resend OTP
if(isset($_POST['resend']))
{
$message="<p class='w3-text-green'>Sucessfully send OTP to your mail.</p>";
$rno=$_SESSION['otp'];
$to=$_SESSION['email'];
$subject = "OTP";
$txt = "OTP: ".$rno."";
$headers = "From: random_mail@gmail.com";
mail($to,$subject,$txt,$headers);
$message="<p class='w3-text-green w3-center'><b>Sucessfully resend OTP to your mail.</b></p>";
}
?>
<!DOCTYPE html>
<html>
<header>
<title>OTP</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://studentstutorial.com/div/d.css">
<style>
a{
text-decoration:none;
}
</style>
<header>
<body>
<br>
<div class="w3-row">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-green">
<h2>OTP</h2>
</div>
<br>
<form class="w3-container" method="post" action="">
<br>
<br>
<p><input class="w3-input w3-border w3-round" type="password" placeholder="OTP" name="otpvalue"></p>
<p class="w3-center"><button class="w3-btn w3-green w3-round" style="width:100%;height:40px" name="save">Submit</button></p>
<p class="w3-center"><button class="w3-btn w3-green w3-round" style="width:100%;height:40px" name="resend">Resend</button></p>
</form>
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<br>
<div class="w3-container w3-center w3-light-grey">
</div>
</div>
<div class="w3-half">
</div>
</div>
</body>
</html>