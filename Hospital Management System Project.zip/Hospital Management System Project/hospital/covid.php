<!DOCTYPE html>
<html>
<head>
<title> COVID-19</title>
</head>
<style>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 75%;
}
h1{
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 75%;
  color:white;
}
#back_btn{
background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  display: block;
  margin-left: auto;
  margin-right: auto;
}
</style>
<body style="background-color:#182C61;">
<h1> Coronavirus Symptoms</h1>
<img src="images/Symptoms.jpg" height="500" width="800" class="center">
<br><br>
<a href="index.php"><input type="button" id="back_btn" value="Reserve Room"/>

</body>
</html>